INSERT INTO usuario (nome, email, senha, ativo) VALUES ('Admin', 'admin@brewer.com', '$2a$10$aWZOyW3zYEB/0HQWIl.Ofe6eE0J8TtlxWp4NnPc83vNlmX/BATxSS
', 1)