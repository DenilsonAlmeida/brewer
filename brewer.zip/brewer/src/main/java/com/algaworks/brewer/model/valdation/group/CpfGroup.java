package com.algaworks.brewer.model.valdation.group;

public interface CpfGroup {

}
