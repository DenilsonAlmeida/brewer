package com.algaworks.brewer.repository;

import com.algaworks.brewer.model.Estado;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Estados extends JpaRepository<Estado, Long> {

}
