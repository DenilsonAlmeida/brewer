package com.algaworks.brewer.repository;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.algaworks.brewer.model.Cerveja;
import com.algaworks.brewer.repository.filter.CervejaFilter;
import com.algaworks.brewer.repository.helper.cerveja.CervejasQueries;

@Repository
public interface Cervejas extends JpaRepository <Cerveja, Long>, CervejasQueries {
	
	

	

	public Page<Cerveja> filtrar(CervejaFilter cervejaFilter, Pageable pageable);

	

	

}
