package com.algaworks.brewer.model.validation.group;

public interface CpfGroup {

}
